package board;

public enum Colors {
    WHITE,
    BLACK,
    GRAY, //culoare ajutatoare
}
